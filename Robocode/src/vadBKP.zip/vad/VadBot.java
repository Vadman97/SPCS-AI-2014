package vad;

import java.util.ArrayList;
import java.util.Random;

import robocode.AdvancedRobot;
//import java.awt.Color;
import robocode.BulletHitBulletEvent;
import robocode.BulletHitEvent;
import robocode.BulletMissedEvent;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import robocode.ScannedRobotEvent;
import robocode.SkippedTurnEvent;
import robocode.StatusEvent;

// API help : http://robocode.sourceforge.net/docs/robocode/robocode/Robot.html

/**
 * VadBot - a robot by Vadim Korolik
 * 
 * @author Vadim Korolik
 * @author Help from James
 */
public class VadBot extends AdvancedRobot
{
	public Random								rand			= new Random();
	public int									numOtherPlayers	= 0;
	public ArrayList<InstantaneousEnemyData>	instEnemyData	= new ArrayList<InstantaneousEnemyData>();
	public ArrayList<ContinuousEnemyData>		constEnemyData	= new ArrayList<ContinuousEnemyData>();

	@Override
	public void onBulletHit(BulletHitEvent event)
	{

	}

	@Override
	public void onBulletHitBullet(BulletHitBulletEvent event)
	{

	}

	@Override
	public void onBulletMissed(BulletMissedEvent event)
	{

	}

	/**
	 * onHitByBullet: What to do when you're hit by a bullet
	 */
	@Override
	public void onHitByBullet(HitByBulletEvent e)
	{
		// Replace the next line with any behavior you would like
		this.back(10);
	}

	@Override
	public void onHitRobot(HitRobotEvent e)
	{

	}

	/**
	 * onHitWall: What to do when you hit a wall
	 */
	@Override
	public void onHitWall(HitWallEvent e)
	{
		// Replace the next line with any behavior you would like
		this.back(20);
	}

	/**
	 * onScannedRobot: What to do when you see another robot
	 */
	@Override
	public void onScannedRobot(ScannedRobotEvent e)
	{
		for (InstantaneousEnemyData ed : this.instEnemyData)
		{
			if (!ed.hasRealData())
			{
				boolean goingToUpdate = true;
				for (InstantaneousEnemyData ed2 : this.instEnemyData)
				{
					System.out.println("Checking if already created such robot");
					if (ed2.isName(e.getName()))
					{
						goingToUpdate = false;
					}
				}
				if (goingToUpdate)
				{
					System.out.println("Found new robot! " + e.getName());
					ed.updateData(e);
				}
			} else
			{
				if (!ed.recentlyUpdated(this.getTime()))
				{
					System.out.println("Updating data! " + "Last scan time: " + ed.getEnemyScanTime() + " Current time: " + this.getTime());
					ed.updateData(e);
				}
			}
		}

		for (ContinuousEnemyData ed : this.constEnemyData)
		{
			if (ed.getRobotName() == null)
			{
				boolean goingToUpdate = true;
				for (ContinuousEnemyData ed2 : this.constEnemyData)
				{
					System.out.println("Checking if already created such robot");
					if (ed2.getRobotName() == e.getName())
					{
						goingToUpdate = false;
					}
				}
				if (goingToUpdate)
				{
					System.out.println("Found new robot! " + e.getName());
					ed.setRobotName(e.getName());
					ed.addData(e);
				}
			} else
			{
				//System.out.println("Adding data! " + "Last scan time: " + ed.getEnemyScanTime() + " Current time: " + this.getTime());
				ed.addData(e);
			}
		}
	}

	@Override
	public void onSkippedTurn(SkippedTurnEvent event)
	{
		System.out.println("Skipped turn num: " + event.getSkippedTurn());
	}

	/*
	 * This method is called every turn in a battle round in order to provide
	 * the robot status as a complete snapshot of the robot's current state at
	 * that specific time.
	 */
	@Override
	public void onStatus(StatusEvent e)
	{

	}

	@Override
	public void run()
	{
		this.numOtherPlayers = this.getOthers();
		this.setAdjustRadarForGunTurn(true);
		this.setAdjustRadarForRobotTurn(true);
		this.setAdjustGunForRobotTurn(true);

		System.out.println("Num other players: " + this.numOtherPlayers);

		for (int i = 0; i < this.numOtherPlayers; i++)
		{
			this.instEnemyData.add(new InstantaneousEnemyData(i));
			this.constEnemyData.add(new ContinuousEnemyData(i));
		}

		this.setTurnRadarRightRadians(Double.POSITIVE_INFINITY);
		this.execute();
		while (true)
		{
			this.scan();
		}
	}
}
