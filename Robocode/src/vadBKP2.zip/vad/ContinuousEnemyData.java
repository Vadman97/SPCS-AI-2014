package vad;

import java.util.ArrayList;
import java.util.HashMap;

import robocode.ScannedRobotEvent;

public class ContinuousEnemyData
{
	private String										robotName;
	private int											robotIndex;
	private int											dataIndex	= 0;
	private HashMap<Integer, InstantaneousEnemyData>	rollingData;

	public ContinuousEnemyData(int robotIndex)
	{
		this.robotName = null;
		this.robotIndex = robotIndex;
		this.rollingData = new HashMap<Integer, InstantaneousEnemyData>();
	}

	public ContinuousEnemyData(int robotIndex, String robotName)
	{
		this(robotIndex);
		this.robotName = robotName;
	}
	
	public ContinuousEnemyData(String robotName)
	{
		this(-1, robotName);
	}
	
	public boolean recentlyUpdated(long time)
	{
		if (this.rollingData.size() == 0) return false;
		if (rollingData.get(new Integer(rollingData.size() - 1)).recentlyUpdated(time)) return true;
		return false;
	}

	public void addData(ScannedRobotEvent e)
	{
		this.rollingData.put(new Integer(this.dataIndex),
				new InstantaneousEnemyData(this.robotIndex, e));
		this.dataIndex++;
	}

	public int getDataIndex()
	{
		return this.dataIndex;
	}

	public ArrayList<InstantaneousEnemyData> getLastData(int numOfLatestDataSets)
	{
		if (numOfLatestDataSets > this.rollingData.size()) 
			return null;
		ArrayList<InstantaneousEnemyData> temp = new ArrayList<InstantaneousEnemyData>();
		for (int i = this.rollingData.size() - 1; i > (this.rollingData.size() - numOfLatestDataSets - 1); i--)
			temp.add(this.rollingData.get(new Integer(i)));
		
		return temp;
	}

	public int getRobotIndex()
	{
		return this.robotIndex;
	}

	public String getRobotName()
	{
		return this.robotName;
	}

	public void setRobotIndex(int robotIndex)
	{
		this.robotIndex = robotIndex;
	}

	public void setRobotName(String robotName)
	{
		this.robotName = robotName;
	}
}
