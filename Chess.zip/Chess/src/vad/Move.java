package vad;

public class Move
{
	private Position start;
	private Position dest;
	private Piece killedPiece;
	
	public Move(GameBoard b, Position start, Position dest)
	{
		this.start = start;
		this.dest = dest;
		killedPiece=b.getPiece(dest);
	}
	

	public Position getStartPosition()
	{
		return start;
	}
	
	public Position getDestPosition()
	{
		return dest;
	}


	public Piece getKilledPiece()
	{
		return killedPiece;
	}
}
